import React from 'react';
import Typewriter from 'typewriter-effect';
import { motion } from 'framer-motion';
import { Bot, Brain, Cpu, BotIcon as RobotIcon } from 'lucide-react';

function App() {
  return (
    <div className="relative min-h-screen bg-black text-white overflow-hidden">
      {/* Grid Background */}
      <div className="absolute inset-0 hero-grid opacity-20"></div>

      {/* Spline Viewer */}
      <div className="spline-viewer-container">
        <spline-viewer url="https://prod.spline.design/IIgtsNriYyVGslon/scene.splinecode"></spline-viewer>
      </div>

      {/* Hero Content */}
      <div className="relative z-10 min-h-screen flex items-center">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl relative z-20">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h1 className="text-5xl sm:text-7xl font-bold mb-6 flex items-center gap-4">
                <RobotIcon className="w-12 h-12 sm:w-16 sm:h-16 text-white" strokeWidth={1.5} />
                <span className="text-glow">Rogue AI</span>
              </h1>
              
              <div className="text-xl sm:text-2xl text-gray-400 mb-8 h-20">
                <Typewriter
                  options={{
                    strings: [
                      'Automating the future',
                      'Revolutionizing businesses',
                      'Empowering innovation'
                    ],
                    autoStart: true,
                    loop: true,
                    delay: 50,
                    deleteSpeed: 30
                  }}
                />
              </div>

              <div className="space-y-4 mb-12">
                <motion.div
                  className="flex items-center space-x-3"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.2 }}
                >
                  <Brain className="w-6 h-6" />
                  <span>Advanced AI Solutions</span>
                </motion.div>
                <motion.div
                  className="flex items-center space-x-3"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 }}
                >
                  <Bot className="w-6 h-6" />
                  <span>Custom Automation</span>
                </motion.div>
                <motion.div
                  className="flex items-center space-x-3"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.6 }}
                >
                  <Cpu className="w-6 h-6" />
                  <span>Enterprise Integration</span>
                </motion.div>
              </div>

              <motion.div
                className="flex space-x-4"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.8 }}
              >
                <button className="px-8 py-3 bg-white text-black font-semibold rounded-full hover:bg-gray-200 transition-colors">
                  Get Started
                </button>
                <button className="px-8 py-3 border border-white rounded-full hover:bg-white hover:text-black transition-all">
                  Learn More
                </button>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;